sap.ui.define([
	"zfsaccountcreation/test/unit/controller/MainWizard.controller"
], function () {
	"use strict";
});
