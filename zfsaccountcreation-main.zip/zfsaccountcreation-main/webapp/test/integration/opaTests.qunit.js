/* global QUnit */

sap.ui.require(["zfsaccountcreation/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
